create procedure sp_viewLastCourierRoute(IN courier varchar(255))
  BEGIN
  set @armc_id = (SELECT arc1.id
                  FROM arm_results_collection arc1 
                    WHERE arc1.courier_ref = courier
                       ORDER BY arc1.id DESC LIMIT 1);
  
SELECT   e.id AS EWId,
         e.ml_id,
         e.ref AS EWref,
         m.ref AS mlRef,
         r.id AS routeId,
         arc.district_ref,        
         e.number,

     /* e.has_time_interval,
      e.time_interval_from,
      e.time_interval_to,
      e.has_time_interval,*/
      r.will_visit_point_at,
       e.courier_status,
      e.operator_status,

      ebp.geo_item_id,        
      arc.id AS armc_resId,
      ar.id AS arm_ResId,
      r.duration,
      gi.phone,
      arc.courier_ref,
      e.cancelled_at,
      arc.created_at,/*дата формирования маршрута*/
      r.completed_at /*якщо всі ЕН в накладній закриті то проставляється дата*/  
   FROM arm_results_collection arc
      JOIN arm_result ar ON arc.id = ar.arm_results_collection_id
      JOIN route r ON r.arm_result_id = ar.id
      JOIN geo_item gi ON r.id = gi.route_id
      JOIN ews_by_phone ebp ON gi.id = ebp.geo_item_id
      JOIN ew e ON ebp.ew_id = e.id
      JOIN ml m ON e.ml_id = m.id
 WHERE arc.id = @armc_id;


END;

