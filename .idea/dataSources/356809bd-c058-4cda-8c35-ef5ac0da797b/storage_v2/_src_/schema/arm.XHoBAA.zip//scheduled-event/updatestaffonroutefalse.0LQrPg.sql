create definer = dmitriy@`%` event updateStaffOnRouteFalse
  on schedule
    every '1' DAY
      starts '2019-02-13 10:09:01'
      ends '2019-02-13 12:17:54'
  enable
  comment 'Update staff on_route status'
do
  UPDATE arm.staff s
  SET s.on_route_status = 0
  WHERE s.ref IN ('35003532-92f1-11e2-a57a-d4ae527baec3','eb0658f0-e20f-11e1-ba0d-d4ae527baec9');

