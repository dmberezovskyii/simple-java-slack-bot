create procedure sp_deleteRouteByCourierRefAtCurrentDay(IN courier varchar(255))
  comment 'Видалення маршруту для кур"єра (вхідний параметр courier_ref)'
  BEGIN
 truncate table comment;
 SET FOREIGN_KEY_CHECKS = 0;
 SET SQL_SAFE_UPDATES = 0;
 set @date = CURDATE();

IF EXISTS(SELECT * FROM arm_results_collection arc WHERE arc.courier_ref = courier AND arc.created_at >= @date)
THEN 
/*ARM result*/
DELETE FROM ews_by_phone WHERE created_at >= @date AND geo_item_id IN (SELECT gi.id FROM geo_item gi
                                                                                JOIN route r ON gi.route_id = r.id
                                                                                JOIN arm_result ar ON r.arm_result_id = ar.id
                                                                                 JOIN arm_results_collection arc ON ar.arm_results_collection_id = arc.id
                                                                        WHERE arc.courier_ref = courier );

DELETE FROM geo_item WHERE created_at >= @date AND route_id IN (SELECT r.id FROM  route r 
                                                                                JOIN arm_result ar ON r.arm_result_id = ar.id
                                                                                 JOIN arm_results_collection arc ON ar.arm_results_collection_id = arc.id
                                                                        WHERE arc.courier_ref = courier);
DELETE FROM route WHERE arm_result_id IN (SELECT ar.id 
                                              FROM arm_result ar
                                                  JOIN arm_results_collection arc ON ar.arm_results_collection_id = arc.id
                                                     WHERE ar.created_at >=@date    AND arc.courier_ref = courier     );
DELETE FROM arm_result WHERE arm_results_collection_id IN
                                  (SELECT arc.id 
                                    FROM arm_results_collection arc
                                      WHERE arc.created_at >= @date AND arc.courier_ref = courier);

DELETE FROM arm_results_collection WHERE  created_at >= @date AND courier_ref = courier;

END IF;

IF EXISTS(SELECT * FROM ml m WHERE m.courier_ref = courier AND m.created_at >= @date) THEN
/*EW, ML*/
DELETE FROM file WHERE ew_id IN (SELECT ew.id FROM ew WHERE ml_id IN 
                                      (SELECT m.id FROM ml m WHERE m.created_at >= @date  AND m.courier_ref = courier ));
DELETE FROM fixed_location WHERE ew_id IN (SELECT ew.id FROM ew WHERE ml_id IN 
                                      (SELECT m.id FROM ml m WHERE m.created_at >= @date  AND m.courier_ref = courier ));
DELETE FROM notification WHERE autotask_id IN (SELECT a.id FROM autotask a
                                                              JOIN ew e ON a.ew_id = e.id
                                                              JOIN ml m ON e.ml_id = m.id
                                                               WHERE m.created_at >= @date  AND m.courier_ref = courier );
DELETE FROM autotask WHERE ew_id IN (SELECT ew.id FROM ew WHERE ml_id IN 
                                      (SELECT m.id FROM ml m WHERE m.created_at >= @date  AND m.courier_ref = courier ));
DELETE FROM ew WHERE ml_id IN (SELECT m.id FROM ml m WHERE m.created_at >= @date  AND m.courier_ref = courier );
DELETE FROM ml WHERE created_at >= @date AND courier_ref = courier ;

/*Видалити перерви встановлені кур"єром
DELETE FROM lunch WHERE courier_ref = @courier;
/*Зміна статусу кур"єра*/
UPDATE arm.staff s
  SET s.on_route_status = 0
  WHERE s.ref = courier;
END IF;

END;

